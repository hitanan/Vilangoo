# Vilangoo
Vilangoo là ứng dụng học tiếng Anh thông qua những câu giao tiếp thông dụng nhất
- Phát âm chuẩn hình ảnh thu hút.
- Phân thành từng chủ đề giao tiếp hằng ngày.
- Áp dụng công nghệ nhắc - nhớ, đã được khoa học chứng minh tính hiệu quả.

